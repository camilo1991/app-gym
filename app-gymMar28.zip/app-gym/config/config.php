
<?php
$host = 'localhost';
$db   = 'mndcuvmq_gym_db'; // Reemplaza con el nombre real de tu DB
$user = 'mndcuvmq_admin_gym'; 
$pass = 'Camilo1012380314*'; // La que generaste en el panel
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Si hay error de conexión, esto lo mostrará
    die("Error de conexión: " . $e->getMessage());
}